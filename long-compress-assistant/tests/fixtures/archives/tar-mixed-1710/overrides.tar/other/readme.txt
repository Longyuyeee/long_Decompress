same leaf name, different folder
